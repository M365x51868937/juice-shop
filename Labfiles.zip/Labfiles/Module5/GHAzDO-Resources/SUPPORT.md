# Support

## How to file issues and get help  

This project uses GitHub Issues to track bugs and feature requests. Please search the existing
issues before filing new issues to avoid duplicates.  For new issues, file your bug or
feature request as a new Issue.

For help and questions about using this project, please reach out to Azure DevOps or GHAS support as appropriate

## Microsoft Support Policy  

Support for these samples is limited to the resources listed above.
